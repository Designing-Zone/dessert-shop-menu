from django.urls import path

from . import views

app_name = "menu"

urlpatterns = [
    path("", views.menu_view, name="menu"),
    path("robots.txt", views.robots_txt, name="robots"),
]
